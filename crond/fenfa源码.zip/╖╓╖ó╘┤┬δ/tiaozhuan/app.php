<?php
function qianmian( $length = 4 )
{
    // 密码字符集，可任意添加你需要的字符
    $chars = array('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h','i', 'j', 'k', 'l','m', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y','z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
    // 在 $chars 中随机取 $length 个数组元素键名
    $keys = array_rand($chars, $length); 
    $password = '';
    for($i = 0; $i < $length; $i++)
    {
        // 将 $length 个数组元素连接成字符串
        $password .= $chars[$keys[$i]];
    }
    return $password;
}
function houmian( $length = 15 )
{
    // 密码字符集，可任意添加你需要的字符
    $chars = array('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l','m', 'n', 'o', 'p', 'q', 'r', 's','t', 'u', 'v', 'w', 'x', 'y','z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L','M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y','Z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
    // 在 $chars 中随机取 $length 个数组元素键名
    $keys = array_rand($chars, $length); 
    $houmian = '';
    for($i = 0; $i < $length; $i++)
    {
        // 将 $length 个数组元素连接成字符串
        $houmian .= $chars[$keys[$i]];
    }
    return $houmian;
}
$qianmian = qianmian();
$houmian = houmian();
$tiaozhuan = 'https://'.$qianmian.".bfenfa.com".$_SERVER['REQUEST_URI'].'?'.$houmian;
?>
<html>
	<head>

</head>
<body>
	<script type="text/javascript">
	function is_weixin() {
      var UserAgent = navigator.userAgent.toLowerCase();
      if (UserAgent.match(/MicroMessenger/i) == "micromessenger") {
          return true;
      } 
      else {
          return false;
      }
		}
       function isQQApp(){
       	var UserAgent = navigator.userAgent.toLowerCase();
        var android = UserAgent.indexOf('android');
        var iphone = UserAgent.indexOf('iphone');
        if(android > 0){
            var qqapp_sq = UserAgent.indexOf('v1_and_sq');
            var qqapp_d = UserAgent.indexOf('yyb_d');
            var qq = UserAgent.indexOf('qq');
            if(qq > 0 && (qqapp_sq > 0 || qqapp_d > 0))
            {
                return true;
            }

            var qqbrowser = UserAgent.indexOf('mqqbrowser');
            var netType =  UserAgent.indexOf('nettype');
            var webp =  UserAgent.indexOf('webp');
            if(qqbrowser > 0 && netType > 0 && webp >0){
                return true;
            }
        }
        if(iphone > 0){
            var qqbrowser = UserAgent.indexOf('qq/');
            var netType =  UserAgent.indexOf('nettype');

            if(qqbrowser > 0 && netType > 0){
                return true;
            }
        }
        return false;
    }
    var isQQApp = isQQApp();
		var isWeixin = is_weixin();
		var winHeight = typeof window.innerHeight != 'undefined' ? window.innerHeight : document.documentElement.clientHeight;
		function loadHtml(){
			var div = document.createElement('div');
			div.id = 'weixin-tip';
			var UserAgent = navigator.userAgent.toLowerCase();
        	var android = UserAgent.indexOf('android');
        	var iphone = UserAgent.indexOf('iphone');
			if(iphone > 0){
			div.innerHTML = '<p><img src="https://ae01.alicdn.com/kf/H85f873aebb3544c5913af32f5f004fc6j.png" alt="微信打开"/></p>';
			}else{
				div.innerHTML = '<p><img src="https://ae01.alicdn.com/kf/H4be4e4920df842aeb6c3a492eff4f5717.png" alt="微信打开"/></p>';
			}
			document.body.appendChild(div);
		}
		
		function loadStyleText(cssText) {
	        var style = document.createElement('style');
	        style.rel = 'stylesheet';
	        style.type = 'text/css';
	        try {
	            style.appendChild(document.createTextNode(cssText));
	        } catch (e) {
	            style.styleSheet.cssText = cssText; //ie9以下
	        }
            var head=document.getElementsByTagName("head")[0]; //head标签之间加上style样式
            head.appendChild(style); 
	    }
	    var cssText = "#weixin-tip{position: fixed; left:0; top:0; background: rgba(f,f,f,0.8); filter:alpha(opacity=80); width: 100%; height:100%; z-index: 100;} #weixin-tip p{text-align: center;height: 100%;}#weixin-tip img {width: 100%;background-size: cover;}";
		if(isWeixin){
			loadHtml();
			loadStyleText(cssText);
		}else if(isQQApp){
			loadHtml();
			loadStyleText(cssText);
		}else{
            window.location.href='<?php echo $tiaozhuan; ?>';
        }
</script>
</body>
</html>