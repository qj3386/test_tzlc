<?php


namespace CFPropertyList;
class PListException extends \Exception {
}

?>