<?php
namespace ApkParser;
abstract class Xml
{
}
?>