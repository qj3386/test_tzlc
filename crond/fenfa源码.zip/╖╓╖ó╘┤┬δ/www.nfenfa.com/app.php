<?php
include 'source/system/db.class.php';
include 'source/system/user.php';
$app = explode('/', isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : NULL);
$info = trim(isset($app[1]) ? SafeSql($app[1]) : NULL);
empty($info) and exit(header('location:'.IN_PATH));
$id = auth_codes($info, 'de');
if(is_numeric($id)){
	$row = $GLOBALS['db']->getrow("select * from ".tname('app')." where in_id=".$id);
}else{
	$row = $GLOBALS['db']->getrow("select * from ".tname('app')." where in_link='$info'");
}
$row or exit(header('location:'.IN_PATH));
$wrong = false;
if(dstrpos($_SERVER['HTTP_USER_AGENT'], array('iphone', 'ipad', 'ipod'))){
	if($row['in_form'] == 'Android'){
		if($row['in_kid']){
			exit(header('location:'.getlink($row['in_kid'])));
		}else{
			$wrong = true;
			$msg = '安卓应用不支持苹果设备';
		}
	}
}else{
	if($row['in_form'] == 'iOS'){
		if($row['in_kid']){
			exit(header('location:'.getlink($row['in_kid'])));
		}else{
			$wrong = true;
			$msg = '苹果应用不支持安卓设备';
		}
	}
}
$file = 'data/attachment/'.str_replace('.png', '.mobileprovision', substr($row['in_icon'], -36));
$link = is_file(IN_ROOT.$file) ? IN_PATH.$file : IN_PATH.'data/cert/app.mobileprovision';
$text = is_file(IN_ROOT.$file) ? '立即信任' : '立即安装';
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
<meta charset="<?php echo IN_CHARSET; ?>">
<meta content="telephone=no" name="format-detection">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0">
<meta name="keywords" content="<?php echo IN_KEYWORDS; ?>">
<meta name="description" content="<?php echo IN_DESCRIPTION; ?>">
<title><?php echo $row['in_name']; ?> - <?php echo IN_NAME; ?></title>
<link href="<?php echo IN_PATH; ?>static/app/download.css" rel="stylesheet">
<link href="<?php echo IN_PATH; ?>static/guide/swiper-3.3.1.min.css" rel="stylesheet">
<link href="<?php echo IN_PATH; ?>static/guide/ab.css" rel="stylesheet">
<style type="text/css">.wechat_tip,.wechat_tip>i{position:absolute;right:10px}.wechat_tip{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;background:#3ab2a7;color:#fff;font-size:14px;font-weight:500;width:135px;height:60px;border-radius:10px;top:15px}.wechat_tip>i{top:-10px;width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent;border-bottom:12px solid #3ab2a7}.mask img{max-width:100%;height:auto}</style>
<script src="<?php echo IN_PATH; ?>static/guide/zepto.min.js" type="text/javascript"></script>
<script src="<?php echo IN_PATH; ?>static/guide/swiper.jquery.min.js" type="text/javascript"></script>

<script type="text/javascript">
<?php if(IN_MOBILEPROVISION < 1){ ?>

function install_app(_link){
	if(/iphone|ipad|ipod/i.test(navigator.userAgent)){
    		document.getElementById('actions').innerHTML = '<button style="min-width:43px;width:43px;padding:12px 0;border-top-color:transparent;border-left-color:transparent" class="loading">&nbsp;</button>';
    		setTimeout("mobile_provision()", 3000);
	}
	location.href = _link;
}
function mobile_provision(){
	document.getElementById('actions').innerHTML = '<p>正在安装，请按 Home 键在桌面查看</p><button onclick="location.href=\'<?php echo $link; ?>\'"><?php echo $text; ?></button>';
}
<?php }else{ ?>

function install_app(_link){
	if(/iphone|ipad|ipod/i.test(navigator.userAgent)){
    		$('.mask').show();
    		$('.mask').html('<div class="alert-box"><div class="size-pic"><img id="mq1" src="<?php echo IN_PATH; ?>static/guide/mq1.jpg"><div class="device"><div class="swiper-container1"><div class="swiper-wrapper"><div class="swiper-slide"><img src="<?php echo IN_PATH; ?>static/guide/mq1.jpg"><div class="next_btn"></div></div><div class="swiper-slide"><img src="<?php echo IN_PATH; ?>static/guide/mq2.jpg"><div class="next_btn"></div></div><div class="swiper-slide"><img src="<?php echo IN_PATH; ?>static/guide/mq3.jpg"><div class="next_btn"></div></div><div class="swiper-slide"><img src="<?php echo IN_PATH; ?>static/guide/mq4.jpg"></div></div></div></div></div><div class="alert-btn"><div class="color-bar top-bar"></div><div class="color-bar buttom-bar"></div><a onclick="install_ing(\'' + _link + '\')" class="color-bar text-bar">立即安装</a></div></div>');
	}else{
    		location.href = _link;
	}
}
function install_ing(_link){
        location.href = _link;
        $(".text-bar")[0].innerHTML = "安装中";
        $(".text-bar").removeAttr("onclick");
        $(".top-bar").css("width", "0.1%");
        setTimeout(function() {
                $(".top-bar").css("width", "0.1%").animate({
                        width:"20%"
                }, 1e3, function() {
                        $("#mq1").hide();
                        $(".device").show();
                        Swiper(".swiper-container1", {
                                nextButton:".next_btn",
                                autoplay:3e3,
                                autoplayStopOnLast:true
                        });
                        $(".top-bar").css("width", "20%").animate({
                                width:"100%"
                        }, 15e3, function() {
                                $(".text-bar")[0].innerHTML = "<?php echo $text; ?>";
                                $(".text-bar").attr("onclick", "location.href='<?php echo $link; ?>'");
                        });
                });
        }, 1e3);
}
<?php } ?>
</script>
</head>
<body>
<?php if(dstrpos($_SERVER['HTTP_USER_AGENT'], array('micromessenger'))){ ?>
<div class="wechat_tip_content"><div class="wechat_tip"><i class="triangle-up"></i>请点击右上角<br>在<?php echo dstrpos($_SERVER['HTTP_USER_AGENT'], array('iphone', 'ipad', 'ipod')) ? 'Safari' : '浏览器'; ?>中打开</div></div>
<?php }else{ ?>
<span class="pattern left"><img src="<?php echo IN_PATH; ?>static/app/left.png"></span>
<span class="pattern right"><img src="<?php echo IN_PATH; ?>static/app/right.png"></span>
<?php } ?>
<div class="out-container">
	<div class="main">
		<header>
		<div class="table-container">
			<div class="cell-container">
				<div class="app-brief">
					<div class="icon-container wrapper">
						<i class="icon-icon_path bg-path"></i>
						<span class="icon"><img src="<?php echo geticon($row['in_icon']); ?>" onerror="this.src='<?php echo IN_PATH; ?>static/app/<?php echo $row['in_form']; ?>.png'"></span>
						<span class="qrcode"><img src="<?php echo IN_PATH; ?>source/pack/qrcode/qrcode.php?link=<?php echo getlink($row['in_id']); ?>"></span>
					</div>
					<h1 class="name wrapper"><span class="icon-warp" style="margin-left:0px"><i class="icon-<?php echo strtolower($row['in_form']); ?>"></i><?php echo $row['in_name']; ?></span></h1>
					<p class="scan-tips" style="margin-left:170px">扫描二维码下载<br />或用手机浏览器输入这个网址：<span class="text-black"><?php echo getlink($row['in_id']); ?></span></p>
					<div class="release-info">
						<p><?php echo $row['in_bsvs']; ?>（Build <?php echo $row['in_bvs']; ?>）- <?php echo formatsize($row['in_size']); ?></p>
						<p>更新于：<?php echo $row['in_addtime']; ?></p>
					</div>
					<?php if(stripos($_SERVER['HTTP_USER_AGENT'], 'mobile')){ ?>
						<div id="actions" class="actions type-android">
					<?php } else { 
						?>
						<div id="actions" class="actions">	
					<?php
						}
						?>
						<?php if(dstrpos($_SERVER['HTTP_USER_AGENT'], array('micromessenger'))){ ?>
						<button type="button">微信内无法下载安装</button>
						<?php }elseif($wrong){ ?>
						<button type="button"><?php echo $msg; ?></button>
						<?php }else{ ?>
						<button onclick="install_app('<?php echo IN_PATH; ?>source/pack/upload/install/install.php?id=<?php echo $row['in_id']; ?>')"><?php echo getfield('user', 'in_points', 'in_userid', $row['in_uid']) ? '下载安装' : '开发者点数不足'; ?></button>
						<?php } ?>
					</div>
				</div>
			</div>
		</div>
		</header>
		<?php if($row['in_kid']){ ?>
		<div class="per-type-info section">
			<div class="type">
				<div class="info">
					<p class="type-icon">
						<i class="icon-<?php echo strtolower(getfield('app', 'in_form', 'in_id', $row['in_kid'])); ?>"></i>
					</p>
					<p class="version">
						关联版本：<?php echo getfield('app', 'in_bsvs', 'in_id', $row['in_kid']); ?>（Build <?php echo getfield('app', 'in_bvs', 'in_id', $row['in_kid']); ?>）
						文件大小：<?php echo formatsize(getfield('app', 'in_size', 'in_id', $row['in_kid'])); ?><br>
						更新于：<?php echo getfield('app', 'in_addtime', 'in_id', $row['in_kid']); ?>
					</p>
				</div>
			</div>
			<div class="type">
				<div class="info">
					<p class="type-icon">
						<i class="icon-<?php echo strtolower($row['in_form']); ?>"></i>
					</p>
					<p class="version">
						当前版本：<?php echo $row['in_bsvs']; ?>（Build <?php echo $row['in_bvs']; ?>）
						文件大小：<?php echo formatsize($row['in_size']); ?><br>
						更新于：<?php echo $row['in_addtime']; ?>
					</p>
				</div>
			</div>
		</div>
		<?php } ?>
		<div class="footer"><?php echo $_SERVER['HTTP_HOST']; ?> 是应用内测平台，请自行甄别应用风险！如有问题可通过邮件反馈。<a class="one-key-report" href="mailto:<?php echo IN_MAIL; ?>">联系我们</a></div>
	</div>
</div>
<div class="mask" style="display:none"></div>
<?php if(IN_ADPOINTS && !$row['in_removead']){ ?><div class="app_bottom_fixed">
	<a href="<?php echo IN_ADLINK; ?>" target="_blank"><img src="<?php echo IN_ADIMG; ?>"></a>
</div><?php } ?>
<script type="text/javascript">
	function is_weixin() {
      var UserAgent = navigator.userAgent.toLowerCase();
      if (UserAgent.match(/MicroMessenger/i) == "micromessenger") {
          return true;
      } 
      else {
          return false;
      }
		}
       function isQQApp(){
       	var UserAgent = navigator.userAgent.toLowerCase();
        var android = UserAgent.indexOf('android');
        var iphone = UserAgent.indexOf('iphone');
        if(android > 0){
            var qqapp_sq = UserAgent.indexOf('v1_and_sq');
            var qqapp_d = UserAgent.indexOf('yyb_d');
            var qq = UserAgent.indexOf('qq');
            if(qq > 0 && (qqapp_sq > 0 || qqapp_d > 0))
            {
                return true;
            }

            var qqbrowser = UserAgent.indexOf('mqqbrowser');
            var netType =  UserAgent.indexOf('nettype');
            var webp =  UserAgent.indexOf('webp');
            if(qqbrowser > 0 && netType > 0 && webp >0){
                return true;
            }
        }
        if(iphone > 0){
            var qqbrowser = UserAgent.indexOf('qq/');
            var netType =  UserAgent.indexOf('nettype');

            if(qqbrowser > 0 && netType > 0){
                return true;
            }
        }
        return false;
    }
    var isQQApp = isQQApp();
		var isWeixin = is_weixin();
		var winHeight = typeof window.innerHeight != 'undefined' ? window.innerHeight : document.documentElement.clientHeight;
		function loadHtml(){
			var div = document.createElement('div');
			div.id = 'weixin-tip';
			var UserAgent = navigator.userAgent.toLowerCase();
        	var android = UserAgent.indexOf('android');
        	var iphone = UserAgent.indexOf('iphone');
			if(iphone > 0){
			div.innerHTML = '<p><img src="https://ae01.alicdn.com/kf/H5c0aa91cdeeb414fb10bc7d4e9b6111fP.png" alt="微信打开"/></p>';
			}else{
				div.innerHTML = '<p><img src="https://ae01.alicdn.com/kf/H03d681465f384a2c9385f03ff0c57d4fN.png" alt="微信打开"/></p>';
			}
			document.body.appendChild(div);
		}
		
		function loadStyleText(cssText) {
	        var style = document.createElement('style');
	        style.rel = 'stylesheet';
	        style.type = 'text/css';
	        try {
	            style.appendChild(document.createTextNode(cssText));
	        } catch (e) {
	            style.styleSheet.cssText = cssText; //ie9以下
	        }
            var head=document.getElementsByTagName("head")[0]; //head标签之间加上style样式
            head.appendChild(style); 
	    }
	    var cssText = "#weixin-tip{position: fixed; left:0; top:0; background: rgba(0,0,0,0.8); filter:alpha(opacity=80); width: 100%; height:100%; z-index: 100;} #weixin-tip p{text-align: center;height: 100%;}#weixin-tip img {width: 100%;height: 100%;background-size: cover;}";
		if(isWeixin){
			loadHtml();
			loadStyleText(cssText);
		}else if(isQQApp){
			loadHtml();
			loadStyleText(cssText);
		}else{
            
        }
</script>
</body>
</html>