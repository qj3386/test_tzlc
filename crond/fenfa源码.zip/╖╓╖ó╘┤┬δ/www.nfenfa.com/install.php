<?php
include 'source/system/config.inc.php';
include 'source/system/function_common.php';

$step = empty($_GET['step']) ? 0 : intval($_GET['step']);
$version = IN_VERSION;
$charset = strtoupper(IN_CHARSET);
$build = IN_BUILD;
$year = date('Y');

$lock = IN_ROOT.'./data/install.lock';
if(file_exists($lock)) {
	show_msg('警告！您已经安装过了！<br>为了保证数据安全，请立即删除{install.php}文件！<br>如果您想重新安装，请删除{data/install.lock}文件！', 999);
}
$sql = IN_ROOT.'./static/install/table.sql';
if(!file_exists($sql)) {
	show_msg('缺少{static/install/table.sql}数据库结构文件，请检查！', 999);
}
$config = IN_ROOT.'./source/system/config.inc.php';
if(!@$fp = fopen($config, 'a')) {
	show_msg('文件{source/system/config.inc.php}读写权限设置错误，请先设置为可写！', 999);
} else {
	@fclose($fp);
}

if(empty($step)) {
	$phpos = PHP_OS;
	$phpversion = PHP_VERSION;
	$attachmentupload = @ini_get('file_uploads') ? '<td class="w pdleft1">'.ini_get('upload_max_filesize').'</td>' : '<td class="nw pdleft1">unknow</td>';
	if(function_exists('disk_free_space')) {
		$diskspace = '<td class="w pdleft1">'.floor(disk_free_space(IN_ROOT) / 1048576).'M</td>';
	} else {
		$diskspace = '<td class="nw pdleft1">unknow</td>';
	}
	$checkok = true;
	$perms = array();
	if(!checkfdperm(IN_ROOT)) {
		$perms['root'] = '<td class="nw pdleft1">不可写</td>';
		$checkok = false;
	} else {
		$perms['root'] = '<td class="w pdleft1">可写</td>';
	}
	if(!checkfdperm(IN_ROOT.'./data/')) {
		$perms['data'] = '<td class="nw pdleft1">不可写</td>';
		$checkok = false;
	} else {
		$perms['data'] = '<td class="w pdleft1">可写</td>';
	}
	if(!checkfdperm(IN_ROOT.'./source/plugin/')) {
		$perms['plugin'] = '<td class="nw pdleft1">不可写</td>';
		$checkok = false;
	} else {
		$perms['plugin'] = '<td class="w pdleft1">可写</td>';
	}
	if(!checkfdperm(IN_ROOT.'./source/system/config.inc.php', 1)) {
		$perms['config'] = '<td class="nw pdleft1">不可写</td>';
		$checkok = false;
	} else {
		$perms['config'] = '<td class="w pdleft1">可写</td>';
	}
	if(is_ssl()) {
		$perms['ssl'] = '<td class="w pdleft1">启用</td>';
	} else {
		$perms['ssl'] = '<td class="nw pdleft1">禁用</td>';
		$checkok = false;
	}
	$check_pdo_mysql = extension_loaded('pdo_mysql') ? '<td class="w pdleft1">支持</td>' : '<td class="nw pdleft1">不支持</td>';
	$check_file_get_contents = function_exists('file_get_contents') ? '<td class="w pdleft1">支持</td>' : '<td class="nw pdleft1">不支持</td>';
	show_header();
	print<<<END
	<div class="setup step1">
	<h2>开始安装</h2>
	<p>环境以及文件目录权限检查</p>
	</div>
	<div class="stepstat">
	<ul>
	<li class="current">检查安装环境</li>
	<li class="unactivated">创建数据库</li>
	<li class="unactivated">设置后台管理员</li>
	<li class="unactivated last">安装</li>
	</ul>
	<div class="stepstatbg stepstat1"></div>
	</div>
	</div>
	<div class="main">

	<h2 class="title">环境检查</h2>
	<table class="tb" style="margin:20px 0 20px 55px;">
	<tr>
	<th>项目</th>
	<th class="padleft">所需配置</th>
	<th class="padleft">最佳配置</th>
	<th class="padleft">当前状态</th>
	</tr>
	<tr>
	<td>操作系统</td>
	<td class="padleft">不限制</td>
	<td class="padleft">类Unix</td>
	<td class="w pdleft1">$phpos</td>
	</tr>
	<tr>
	<td>PHP 版本</td>
	<td class="padleft">5.3.x+</td>
	<td class="padleft">7.0.x+</td>
	<td class="w pdleft1">$phpversion</td>
	</tr>
	<tr>
	<td>附件上传</td>
	<td class="padleft">允许</td>
	<td class="padleft">允许</td>
	$attachmentupload
	</tr>
	<tr>
	<td>磁盘空间</td>
	<td class="padleft">不限制</td>
	<td class="padleft">不限制</td>
	$diskspace
	</tr>
	</table>
	<h2 class="title">目录、文件权限检查</h2>
	<table class="tb" style="margin:20px 0 20px 55px;width:90%;">
	<tr><th>目录文件</th><th class="padleft">所需状态</th><th class="padleft">当前状态</th></tr>
	<tr><td>./</td><td class="w pdleft1">可写</td>$perms[root]</tr>
	<tr><td>./data/</td><td class="w pdleft1">可写</td>$perms[data]</tr>
	<tr><td>./source/plugin/</td><td class="w pdleft1">可写</td>$perms[plugin]</tr>
	<tr><td>./source/system/config.inc.php</td><td class="w pdleft1">可写</td>$perms[config]</tr>
	</table>
	<h2 class="title">网络传输协议检查</h2>
	<table class="tb" style="margin:20px 0 20px 55px;width:90%;">
	<tr><th>协议名称</th><th class="padleft">所需状态</th><th class="padleft">当前状态</th></tr>
	<tr><td>HTTPS</td><td class="w pdleft1">启用</td>$perms[ssl]</tr>
	</table>
	<h2 class="title">扩展、函数依赖性检查</h2>
	<table class="tb" style="margin:20px 0 20px 55px;width:90%;">
	<tr>
	<th>扩展函数</th>
	<th class="padleft">检查结果</th>
	<th class="padleft">建议</th>
	</tr>
	<tr>
	<td>pdo_mysql</td>
	$check_pdo_mysql
	<td class="padleft">无</td>
	</tr>
	<tr>
	<td>file_get_contents()</td>
	$check_file_get_contents
	<td class="padleft">无</td>
	</tr>
	</table>
END;
	if(!$checkok) {
		echo "<div class=\"btnbox marginbot\"><form method=\"post\" action=\"install.php?step=1\"><input type=\"submit\" value=\"强制继续\"><input type=\"button\" value=\"关闭\" onclick=\"windowclose();\"></form></div>";
	} else {
		print <<<END
		<div class="btnbox marginbot">
		<form method="post" action="install.php?step=1">
		<input type="submit" value="同意并安装">
		<input type="button" value="不同意" onclick="windowclose();">
		</form>
		</div>
END;
	}
	show_footer();

} elseif ($step == 1) {
	show_header();
	print<<<END
	<div class="setup step2">
	<h2>安装数据库</h2>
	<p>正在执行数据库安装</p>
	</div>
	<div class="stepstat">
	<ul>
	<li class="unactivated">检查安装环境</li>
	<li class="current">创建数据库</li>
	<li class="unactivated">设置后台管理员</li>
	<li class="unactivated last">安装</li>
	</ul>
	<div class="stepstatbg stepstat1"></div>
	</div>
	</div>
	<div class="main">
	<form name="themysql" method="post" action="install.php?step=2">
	<div class="desc"><b>填写数据库信息</b></div>
	<table class="tb2">
	<tr><th class="tbopt" align="left">&nbsp;数据库主机:</th>
	<td><input type="text" name="dbhost" value="127.0.0.1" size="35" class="txt"></td>
	<td>数据库服务器地址，一般为 localhost</td>
	</tr>
	<tr><th class="tbopt" align="left">&nbsp;数据库名称:</th>
	<td><input type="text" name="dbname" value="test" size="35" class="txt"></td>
	<td>如果不存在，则会尝试自动创建</td>
	</tr>
	<tr><th class="tbopt" align="left">&nbsp;数据库用户名:</th>
	<td><input type="text" name="dbuser" value="root" size="35" class="txt"></td>
	<td></td>
	</tr>
	<tr><th class="tbopt" align="left">&nbsp;数据库密码:</th>
	<td><input type="password" name="dbpw" value="" size="35" class="txt"></td>
	<td></td>
	</tr>
	</table>
	<div class="desc"><b>其它可选设置项</b></div>
	<table class="tb2">
	<tr><th class="tbopt" align="left">&nbsp;数据库表前缀:</th>
	<td><input type="text" name="dbtablepre" value="prefix_" size="35" class="txt"></td>
	<td>不能为空，默认为prefix_</td>
	</tr>
	</table>
	<table class="tb2">
	<tr><th class="tbopt" align="left">&nbsp;</th>
	<td><input type="submit" name="submitmysql" value="创建数据库" onclick="return checkmysql();" class="btn"></td>
	<td></td>
	</tr>
	</table>
	</form>
END;
	show_footer();

} elseif ($step == 2) {
	if(!submitcheck('submitmysql')){show_msg('表单验证不符，无法提交！', 999);}
	$path=$_SERVER['PHP_SELF'];
	$path=str_replace('install.php', '', strtolower($path));
	$host=SafeRequest("dbhost","post");
	$name=SafeRequest("dbname","post");
	$user=SafeRequest("dbuser","post");
	$pw=SafeRequest("dbpw","post");
	$tablepre=SafeRequest("dbtablepre","post");
	$db=install_db_connect($host, $user, $pw);
	$config=file_get_contents("source/system/config.inc.php");
	$config=preg_replace("/'IN_DBHOST', '(.*?)'/", "'IN_DBHOST', '".$host."'", $config);
	$config=preg_replace("/'IN_DBNAME', '(.*?)'/", "'IN_DBNAME', '".$name."'", $config);
	$config=preg_replace("/'IN_DBUSER', '(.*?)'/", "'IN_DBUSER', '".$user."'", $config);
	$config=preg_replace("/'IN_DBPW', '(.*?)'/", "'IN_DBPW', '".$pw."'", $config);
	$config=preg_replace("/'IN_DBTABLE', '(.*?)'/", "'IN_DBTABLE', '".$tablepre."'", $config);
	$config=preg_replace("/'IN_PATH', '(.*?)'/", "'IN_PATH', '".$path."'", $config);
	$ifile=new iFile('source/system/config.inc.php', 'w');
	$ifile->WriteFile($config, 3);
	$havedata = false;
	if(install_db_name($name, $db)) {
		$db = install_db_connect($host, $user, $pw, $name);
		if(install_db_query('SELECT COUNT(*) FROM '.$tablepre.'admin', $db, 1)) {
			$havedata = true;
		}
	} elseif (!install_db_query("CREATE DATABASE `$name`", $db)) {
		show_msg('设定的数据库无权限操作，请先手工新建后，再执行安装程序！');
	}
	if($havedata) {
		show_msg('危险！指定的数据库已有数据，如果继续将会清空原有数据！', ($step+1));
	} else {
		show_msg('数据库信息配置成功，即将开始安装数据...', ($step+1), 1);
	}

} elseif ($step == 3) {
	$db=install_db_connect(IN_DBHOST, IN_DBUSER, IN_DBPW, IN_DBNAME, 999);
	install_db_name(IN_DBNAME, $db) or show_msg('数据库连接异常，无法执行！', 999);
	install_db_set(IN_DBCHARSET, $db);
	$table=file_get_contents("static/install/table.sql");
	$table=str_replace(array('prefix_', '{charset}'), array(IN_DBTABLE, IN_DBCHARSET), $table);
	$tablearr=explode(";",$table);
	$sqlarr=explode("{jie}{gou}*/",$table);
	$str="<p>正在安装数据...</p>{replace}";
	for($i=0;$i<count($tablearr)-1;$i++){
		install_db_query($tablearr[$i], $db);
	}
	for($i=0;$i<count($sqlarr)-1;$i++){
		$strsql=explode("/*{shu}{ju}",$sqlarr[$i]);
		$str.=$strsql[1];
	}
	$str=str_replace(array('{biao} `', '` {de}'), array('<p>建立数据表 ', ' ... 成功</p>{replace}'), $str);
	show_header();
	print<<<END
	<div class="setup step2">
	<h2>安装数据库</h2>
	<p>正在执行数据库安装</p>
	</div>
	<div class="stepstat">
	<ul>
	<li class="unactivated">检查安装环境</li>
	<li class="current">创建数据库</li>
	<li class="unactivated">设置后台管理员</li>
	<li class="unactivated last">安装</li>
	</ul>
	<div class="stepstatbg stepstat1"></div>
	</div>
	</div>
	<div class="main">
	<div class="notice" id="log">
	<div class="license" id="loginner">
	</div>
	</div>
	<div class="btnbox margintop marginbot">
	<input type="button" value="正在安装..." disabled="disabled">
	</div>
	<script type="text/javascript">
	var log = "$str";
	var n = 0;
	var timer = 0;
	log = log.split('{replace}');
	function GoPlay() {
		if (n > log.length-1) {
		        n=-1;
		        clearIntervals();
		}
		if (n > -1) {
		        postcheck(n);
		        n++;
		}
	}
	function postcheck(n) {
		document.getElementById('loginner').innerHTML += log[n];
		document.getElementById('log').scrollTop = document.getElementById('log').scrollHeight;
	}
	function setIntervals() {
		timer = setInterval('GoPlay()', 100);
	}
	function clearIntervals() {
		clearInterval(timer);
		location.href = "install.php?step=4";
	}
	setTimeout(setIntervals, 25);
	</script>
END;
	show_footer();

} elseif ($step == 4) {
	show_header();
	print<<<END
	<div class="setup step3">
	<h2>创建管理员</h2>
	<p>正在设置后台管理帐号</p>
	</div>
	<div class="stepstat">
	<ul>
	<li class="unactivated">检查安装环境</li>
	<li class="unactivated">创建数据库</li>
	<li class="current">设置后台管理员</li>
	<li class="unactivated last">安装</li>
	</ul>
	<div class="stepstatbg stepstat1"></div>
	</div>
	</div>
	<div class="main">
	<form name="theuser" method="post" action="install.php?step=5">
	<div class="desc"><b>填写管理员信息</b></div>
	<table class="tb2">
	<tr><th class="tbopt" align="left">&nbsp;管理员帐号:</th>
	<td><input type="text" name="uname" value="" size="35" class="txt"></td>
	<td>仅限邮箱格式</td>
	</tr>
	<tr><th class="tbopt" align="left">&nbsp;管理员密码:</th>
	<td><input type="password" name="upw" value="" size="35" class="txt"></td>
	<td>密码设置越复杂，安全级别越高</td>
	</tr>
	<tr><th class="tbopt" align="left">&nbsp;重复密码:</th>
	<td><input type="password" name="upw1" value="" size="35" class="txt"></td>
	<td></td>
	</tr>
	<tr><th class="tbopt" align="left">&nbsp;认证码:</th>
	<td><input type="text" name="ucode" value="" size="35" class="txt"></td>
	<td>设置后，可以在后台选择开启或关闭</td>
	</tr>
	</table>
	<table class="tb2">
	<tr><th class="tbopt" align="left">&nbsp;</th>
	<td><input type="submit" name="submituser" value="创建管理员" onclick="return checkuser();" class="btn"></td>
	<td></td>
	</tr>
	</table>
	</form>
END;
	show_footer();

} elseif ($step == 5) {
	if(!submitcheck('submituser')){show_msg('表单验证不符，无法提交！', 999);}
	$db=install_db_connect(IN_DBHOST, IN_DBUSER, IN_DBPW, IN_DBNAME, 999);
	install_db_name(IN_DBNAME, $db) or show_msg('数据库连接异常，无法执行！', 999);
	install_db_set(IN_DBCHARSET, $db);
	$name=SafeRequest("uname","post");
	$pw=SafeRequest("upw","post");
	$pw1=SafeRequest("upw1","post");
	$code=SafeRequest("ucode","post");
	$str=file_get_contents("source/system/config.inc.php");
	$str=preg_replace("/'IN_CODE', '(.*?)'/", "'IN_CODE', '".$code."'", $str);
	$ifile=new iFile('source/system/config.inc.php', 'w');
	$ifile->WriteFile($str, 3);
	$sql="insert into `".tname('admin')."` (in_adminname,in_adminpassword,in_loginnum,in_islock,in_permission) values ('".$name."','".md5($pw1)."','0','0','1,2,3,4,5,6,7')";
	$sqls="insert into `".tname('user')."` (in_username,in_userpassword,in_regdate,in_logintime,in_verify,in_islock,in_points,in_spaceuse,in_spacetotal) values ('".$name."','".substr(md5($pw1), 8, 16)."','".date('Y-m-d H:i:s')."','".date('Y-m-d H:i:s')."','0','0','".IN_LOGINPOINTS."','0','".(IN_REGSPACE * 1048576)."')";
	$sql1="insert into `".tname('plugin')."` (in_name,in_dir,in_file,in_type,in_author,in_address,in_addtime) values ('阿里云存储[分发]','App-oss','upload','0','EarDev','http://www.eardev.com/','".date('Y-m-d H:i:s')."')";
	$sql2="insert into `".tname('plugin')."` (in_name,in_dir,in_file,in_type,in_author,in_address,in_addtime) values ('七牛云存储[分发]','App-qiniu','upload','0','EarDev','http://www.eardev.com/','".date('Y-m-d H:i:s')."')";
	if(install_db_query($sql, $db) && install_db_query($sqls, $db) && install_db_query($sql1, $db) && install_db_query($sql2, $db)) {
		fwrite(fopen('data/install.lock', 'wb+'), time());
		show_msg('恭喜！ 顺利安装完成！<br>为了保证数据安全，请手动删除{static/install}目录！<br><br>您的后台管理员帐号与前台会员帐号已经成功建立。接下来，您可以：<br><br><a href="index.php" target="_blank">进入网站首页</a><br>或 <a href="admin.php" target="_blank">进入管理后台</a> 以管理员身份对站点参数进行设置！', 999);
	} else {
		show_msg(install_db_error($db), 999);
	}
}

function show_header() {
	global $version, $charset, $build;
	print<<<END
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=$charset" />
	<title>安装向导</title>
	<link rel="stylesheet" href="./static/install/images/style.css" type="text/css" media="all" />
	<link href="./static/pack/asynctips/asynctips.css" rel="stylesheet" type="text/css" />
	<script type="text/javascript" src="./static/pack/asynctips/jquery.min.js"></script>
	<script type="text/javascript" src="./static/pack/asynctips/asyncbox.v1.4.5.js"></script>
	<script type="text/javascript">
	function isEmail(input) {
        	if (input.match(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/)) {
        		return true;
        	}
        	return false;
	}
	function windowclose() {
        	var browserName = navigator.appName;
        	if (browserName=="Microsoft Internet Explorer") {
        		window.opener = "whocares";
        		window.opener = null;
        		window.open('', '_top');
        		window.close();
        	} else if (browserName=="Netscape") {
        		window.open('', '_self', '');
        		window.close();
        	}
	}
	function checkmysql() {
        	if (this.themysql.dbhost.value=="") {
        		asyncbox.tips("数据库主机不能为空，请填写！", "wait", 1000);
        		this.themysql.dbhost.focus();
        		return false;
        	} else if (this.themysql.dbname.value=="") {
        		asyncbox.tips("数据库名称不能为空，请填写！", "wait", 1000);
        		this.themysql.dbname.focus();
        		return false;
        	} else if (this.themysql.dbuser.value=="") {
        		asyncbox.tips("数据库用户名不能为空，请填写！", "wait", 1000);
        		this.themysql.dbuser.focus();
        		return false;
        	} else if (this.themysql.dbpw.value=="") {
        		asyncbox.tips("数据库密码不能为空，请填写！", "wait", 1000);
        		this.themysql.dbpw.focus();
        		return false;
        	} else if (this.themysql.dbtablepre.value=="") {
        		asyncbox.tips("数据库表前缀不能为空，请填写！", "wait", 1000);
        		this.themysql.dbtablepre.focus();
        		return false;
        	} else {
        		return true;
        	}
	}
	function checkuser() {
        	if (this.theuser.uname.value=="") {
        		asyncbox.tips("管理员帐号不能为空，请填写！", "wait", 1000);
        		this.theuser.uname.focus();
        		return false;
        	} else if (isEmail(this.theuser.uname.value)==false) {
        		asyncbox.tips("管理员帐号格式有误，请更改！", "error", 1000);
        		this.theuser.uname.focus();
        		return false;
        	} else if (this.theuser.upw.value=="") {
        		asyncbox.tips("管理员密码不能为空，请填写！", "wait", 1000);
        		this.theuser.upw.focus();
        		return false;
        	} else if (this.theuser.upw1.value=="") {
        		asyncbox.tips("重复密码不能为空，请填写！", "wait", 1000);
        		this.theuser.upw1.focus();
        		return false;
        	} else if (this.theuser.upw1.value!==this.theuser.upw.value) {
        		asyncbox.tips("两次输入密码不一致，请更改！", "error", 1000);
        		this.theuser.upw1.focus();
        		return false;
        	} else if (this.theuser.ucode.value=="") {
        		asyncbox.tips("认证码不能为空，请填写！", "wait", 1000);
        		this.theuser.ucode.focus();
        		return false;
        	} else {
        		return true;
        	}
	}
	</script>
	</head>
	<body>
	<div class="container">
	<div class="header">

END;
}

function show_footer() {
	global $year;
	print<<<END
	<div class="footer">&copy;2011 - $year</div>
	</div>
	</div>
	</body>
	</html>
END;
}

function show_msg($message, $next=0, $jump=0) {
	$nextstr = '';
	$backstr = '';
	if(empty($next)) {
		$backstr .= "<a href=\"install.php?step=1\">返回上一步</a>";
	} elseif ($next < 999) {
		$url_forward = "install.php?step=$next";
		if(empty($jump)) {
			$nextstr .= "<a href=\"$url_forward\">继续下一步</a>";
			$backstr .= "<a href=\"install.php?step=1\">返回上一步</a>";
		} else {
			$nextstr .= "<a href=\"$url_forward\">请稍等...</a><script type=\"text/javascript\">setTimeout(\"location.href='$url_forward';\", 1000);</script>";
		}
	}
	show_header();
	print<<<END
	<div class="setup">
	<h2>安装提示</h2>
	</div>
	<div class="stepstat">
	<ul>
	<li class="unactivated">检查安装环境</li>
	<li class="unactivated">创建数据库</li>
	<li class="unactivated">设置后台管理员</li>
	<li class="current last">安装</li>
	</ul>
	<div class="stepstatbg"></div>
	</div>
	</div>
	<div class="main">
	<div class="desc" align="center"><b>提示信息</b></div>
	<table class="tb2">
	<tr><td class="desc" align="center">$message</td>
	</tr>
	</table>
	<div class="btnbox marginbot">$backstr $nextstr</div>
END;
	show_footer();
	exit();
}

function checkfdperm($path, $isfile=0) {
	if($isfile) {
		$file = $path;
		$mod = 'a';
	} else {
		$file = $path.'./install_tmptest.data';
		$mod = 'w';
	}
	if(!@$fp = fopen($file, $mod)) {
		return false;
	}
	if(!$isfile) {
		fwrite($fp, ' ');
		fclose($fp);
		if(!@unlink($file)) {
			return false;
		}
		if(is_dir($path.'./install_tmpdir')) {
			if(!@rmdir($path.'./install_tmpdir')) {
				return false;
			}
		}
		if(!@mkdir($path.'./install_tmpdir')) {
			return false;
		}
		if(!@rmdir($path.'./install_tmpdir')) {
			return false;
		}
	} else {
		fclose($fp);
	}
	return true;
}

function install_db_connect($dbhost, $dbuser, $dbpw, $dbname='', $next=0) {
	if(extension_loaded('pdo_mysql')) {
		try {
			$connect = empty($dbname) ? "mysql:host=$dbhost" : "mysql:host=$dbhost;dbname=$dbname";
			return new PDO($connect, $dbuser, $dbpw);
		} catch(PDOException $e) {
			show_msg($e->getMessage(), $next);
		}
	} else {
		return @mysql_connect($dbhost, $dbuser, $dbpw) or show_msg(mysql_error(), $next);
	}
}

function install_db_name($dbname, $handle) {
	if(extension_loaded('pdo_mysql')) {
		return $handle->query("SHOW TABLES FROM $dbname");
	} else {
		return @mysql_select_db($dbname);
	}
}

function install_db_set($charset, $handle) {
	if(extension_loaded('pdo_mysql')) {
		return $handle->exec("SET NAMES $charset");
	} else {
		return mysql_query("SET NAMES $charset");
	}
}

function install_db_query($sql, $handle, $type=0) {
	if(extension_loaded('pdo_mysql')) {
		if($type) {
			return $handle->query($sql);
		} else {
			return $handle->exec($sql);
		}
	} else {
		return mysql_query($sql);
	}
}

function install_db_error($handle) {
	if(extension_loaded('pdo_mysql')) {
		$info = $handle->errorInfo();
		return $info[2];
	} else {
		return mysql_error();
	}
}
?>